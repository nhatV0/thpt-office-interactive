#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    double a = 7.8, b = 6.4;
    if (cin >> a >> b) {
        // Đọc dữ liệu nếu có input
    }

    double dt = a * b;
    double cv = (a + b) * 2;

    cout << "DT = " << dt << "\n";
    cout << "CV = " << cv << "\n";

    return 0;
}
