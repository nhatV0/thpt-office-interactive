#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    double r;
    if (cin >> r) {
        const double PI = 3.14;
        double c = 2.0 * PI * r;
        double s = PI * r * r;

        cout << fixed << setprecision(1) << c << "\n";
        cout << fixed << setprecision(1) << s << "\n";
    }

    return 0;
}
