#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long a, b;
    if (cin >> a >> b) {
        long long quotient = a / b;
        long long remainder = a % b;
        cout << quotient << " " << remainder << "\n";
    }

    return 0;
}
