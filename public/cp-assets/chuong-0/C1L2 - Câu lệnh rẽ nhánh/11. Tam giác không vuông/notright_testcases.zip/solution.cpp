#include <iostream>
#include <algorithm>

using namespace std;

void solve() {
    unsigned long long ra, rb, rc;
    if (!(cin >> ra >> rb >> rc)) return;

    __int128 a = ra;
    __int128 b = rb;
    __int128 c = rc;

    if (a > b) swap(a, b);
    if (b > c) swap(b, c);
    if (a > b) swap(a, b);

    bool is_triangle = (a + b > c);
    bool is_right = (a * a + b * b == c * c);

    if (is_triangle && !is_right) {
        cout << "YES\n";
    } else {
        cout << "NO\n";
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int t;
    if (cin >> t) {
        while (t--) {
            solve();
        }
    }
    return 0;
}
