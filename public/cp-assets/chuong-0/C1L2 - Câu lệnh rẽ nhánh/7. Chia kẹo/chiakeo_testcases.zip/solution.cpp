#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long n, m;
    if (cin >> n >> m) {
        long long per_child = n / m;
        long long remainder = n % m;
        cout << per_child << " " << remainder << "\n";
    }

    return 0;
}
