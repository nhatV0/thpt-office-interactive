#include <iostream>
#include <cmath>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long n;
    if (cin >> n) {
        if (n <= 0) {
            cout << "NO\n";
        } else {
            long long k = sqrtl((long double)n);
            if (k * k == n || (k + 1) * (k + 1) == n) {
                cout << "YES\n";
            } else {
                cout << "NO\n";
            }
        }
    }

    return 0;
}
