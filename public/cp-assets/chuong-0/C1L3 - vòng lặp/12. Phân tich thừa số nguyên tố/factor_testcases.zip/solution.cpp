#include <iostream>
#include <vector>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long n;
    if (cin >> n) {
        if (n == 1) {
            cout << "1\n1\n";
            return 0;
        }

        vector<long long> factors;
        long long divisors = 1;
        long long temp = n;

        for (long long i = 2; i * i <= temp; ++i) {
            if (temp % i == 0) {
                long long cnt = 0;
                while (temp % i == 0) {
                    factors.push_back(i);
                    cnt++;
                    temp /= i;
                }
                divisors *= (cnt + 1);
            }
        }

        if (temp > 1) {
            factors.push_back(temp);
            divisors *= (1 + 1);
        }

        for (size_t i = 0; i < factors.size(); ++i) {
            if (i > 0) cout << "*";
            cout << factors[i];
        }
        cout << "\n" << divisors << "\n";
    }

    return 0;
}
