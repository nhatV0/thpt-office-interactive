#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long n;
    if (cin >> n) {
        long long count_digits = 0;
        long long sum_digits = 0;
        long long tmp = n;

        while (tmp > 0) {
            sum_digits += tmp % 10;
            count_digits++;
            tmp /= 10;
        }

        cout << count_digits << "\n";
        cout << sum_digits << "\n";
    }

    return 0;
}
