#include <iostream>
#include <vector>

using namespace std;

const int MAX_VAL = 2000000;
const long long MOD = 1000000007LL;

long long fact[MAX_VAL + 1];
long long invFact[MAX_VAL + 1];

long long power(long long base, long long exp) {
    long long res = 1;
    base %= MOD;
    while (exp > 0) {
        if (exp % 2 == 1) res = (res * base) % MOD;
        base = (base * base) % MOD;
        exp /= 2;
    }
    return res;
}

void precompute() {
    fact[0] = 1;
    invFact[0] = 1;
    for (int i = 1; i <= MAX_VAL; ++i) {
        fact[i] = (fact[i - 1] * i) % MOD;
    }

    invFact[MAX_VAL] = power(fact[MAX_VAL], MOD - 2);
    for (int i = MAX_VAL - 1; i >= 1; --i) {
        invFact[i] = (invFact[i + 1] * (i + 1)) % MOD;
    }
}

long long nCr(int a, int b) {
    if (b < 0 || b > a) return 0;
    long long num = fact[a];
    long long den = (invFact[b] * invFact[a - b]) % MOD;
    return (num * den) % MOD;
}

int main() {
    #ifndef ONLINE_JUDGE
    if (fopen("DISTAPPLES.INP", "r")) {
        freopen("DISTAPPLES.INP", "r", stdin);
        freopen("DISTAPPLES.OUT", "w", stdout);
    }
    #endif

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    precompute();

    int n, m;
    if (cin >> n >> m) {
        cout << nCr(n + m - 1, n - 1) << "\n";
    }

    return 0;
}
