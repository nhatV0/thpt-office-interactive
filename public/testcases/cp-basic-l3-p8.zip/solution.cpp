#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    if (cin >> n) {
        bool first = true;
        for (int i = 1; i <= n; ++i) {
            if (i % 3 == 0 && i % 5 != 0) {
                if (!first) cout << " ";
                cout << i;
                first = false;
            }
        }
        cout << "\n";
    }

    return 0;
}
