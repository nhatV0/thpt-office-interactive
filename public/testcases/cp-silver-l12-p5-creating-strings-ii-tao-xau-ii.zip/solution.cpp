#include <iostream>
#include <string>
#include <vector>

using namespace std;

const int MAX_N = 1000000;
const long long MOD = 1000000007LL;

long long fact[MAX_N + 1];
long long invFact[MAX_N + 1];

long long power(long long base, long long exp) {
    long long res = 1;
    base %= MOD;
    while (exp > 0) {
        if (exp % 2 == 1) res = (res * base) % MOD;
        base = (base * base) % MOD;
        exp /= 2;
    }
    return res;
}

void precompute() {
    fact[0] = 1;
    invFact[0] = 1;
    for (int i = 1; i <= MAX_N; ++i) {
        fact[i] = (fact[i - 1] * i) % MOD;
    }

    invFact[MAX_N] = power(fact[MAX_N], MOD - 2);
    for (int i = MAX_N - 1; i >= 1; --i) {
        invFact[i] = (invFact[i + 1] * (i + 1)) % MOD;
    }
}

int main() {
    #ifndef ONLINE_JUDGE
    if (fopen("CREATESTR2.INP", "r")) {
        freopen("CREATESTR2.INP", "r", stdin);
        freopen("CREATESTR2.OUT", "w", stdout);
    }
    #endif

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    precompute();

    string s;
    if (cin >> s) {
        int n = s.length();
        vector<int> cnt(26, 0);
        for (char ch : s) {
            cnt[ch - 'a']++;
        }

        long long ans = fact[n];
        for (int i = 0; i < 26; ++i) {
            if (cnt[i] > 1) {
                ans = (ans * invFact[cnt[i]]) % MOD;
            }
        }

        cout << ans << "\n";
    }

    return 0;
}
