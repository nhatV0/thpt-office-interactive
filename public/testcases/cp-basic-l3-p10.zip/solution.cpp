#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long n, k;
    if (cin >> n >> k) {
        if (k > 0) {
            for (long long i = k; i <= n; i += k) {
                cout << i << "\n";
            }
        }
    }

    return 0;
}
