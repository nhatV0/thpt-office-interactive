#include <iostream>
#include <vector>

using namespace std;

const int MAX_SUM = 800000;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    if (!(cin >> n)) return 0;

    vector<long long> a(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }

    long long k;
    cin >> k;

    vector<long long> cnt(MAX_SUM + 1, 0);

    for (int i = 0; i < n; ++i) {
        long long current_sum = 0;
        for (int j = i; j < n; ++j) {
            current_sum += a[j];
            if (current_sum <= MAX_SUM) {
                cnt[current_sum]++;
            }
        }
    }

    long long ans = 0;

    for (long long d = 1; d * d <= k; ++d) {
        if (k % d == 0) {
            long long d2 = k / d;
            
            long long c1 = (d <= MAX_SUM) ? cnt[d] : 0;
            long long c2 = (d2 <= MAX_SUM) ? cnt[d2] : 0;

            if (d == d2) {
                ans += c1 * c1;
            } else {
                ans += c1 * c2 * 2;
            }
        }
    }

    cout << ans << "\n";

    return 0;
}
