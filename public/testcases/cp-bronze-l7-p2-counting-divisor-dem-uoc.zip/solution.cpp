#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

const int MAX_K = 100000;
int pref[MAX_K + 1];
bool is_prime[MAX_K + 1];
int spf[MAX_K + 1];

long long ceil_sqrt(long long n) {
    if (n <= 0) return 0;
    long long ans = sqrt(n);
    while (ans * ans < n) ans++;
    while ((ans - 1) * (ans - 1) >= n) ans--;
    return ans;
}

long long floor_sqrt(long long n) {
    if (n < 0) return -1;
    long long ans = sqrt(n);
    while ((ans + 1) * (ans + 1) <= n) ans++;
    while (ans * ans > n) ans--;
    return ans;
}

void precompute() {
    for (int i = 2; i <= MAX_K; ++i) {
        is_prime[i] = true;
        spf[i] = i;
    }

    for (int i = 2; i * i <= MAX_K; ++i) {
        if (is_prime[i]) {
            for (int j = i * i; j <= MAX_K; j += i) {
                if (is_prime[j]) {
                    is_prime[j] = false;
                    spf[j] = i;
                }
            }
        }
    }

    for (int k = 2; k <= MAX_K; ++k) {
        bool valid = false;
        for (long long p = 2; p * p * p * p <= k; ++p) {
            if (is_prime[p] && p * p * p * p == k) {
                valid = true;
                break;
            }
        }

        if (!valid) {
            int p1 = spf[k];
            int rem = k / p1;
            if (is_prime[rem] && rem != p1) {
                valid = true;
            }
        }

        pref[k] = pref[k - 1] + (valid ? 1 : 0);
    }
}

void solve() {
    long long L, R;
    if (!(cin >> L >> R)) return;

    long long k_min = ceil_sqrt(L);
    long long k_max = floor_sqrt(R);

    if (k_min > k_max || k_max < 1) {
        cout << 0 << "\n";
        return;
    }

    k_min = max(1LL, k_min);
    k_max = min((long long)MAX_K, k_max);

    if (k_min > k_max) {
        cout << 0 << "\n";
    } else {
        cout << pref[k_max] - pref[k_min - 1] << "\n";
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    precompute();

    int T;
    if (cin >> T) {
        while (T--) {
            solve();
        }
    }

    return 0;
}
