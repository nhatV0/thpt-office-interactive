#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long n;
    if (cin >> n) {
        if ((n % 400 == 0) || (n % 4 == 0 && n % 100 != 0)) {
            cout << "Nam nhuan\n";
        } else {
            cout << "Khong la nam nhuan\n";
        }
    }

    return 0;
}
