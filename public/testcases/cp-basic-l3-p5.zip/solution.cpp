#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long x;
    long long sum = 0;

    while (cin >> x && x != 0) {
        sum += x;
    }

    cout << sum << "\n";

    return 0;
}
