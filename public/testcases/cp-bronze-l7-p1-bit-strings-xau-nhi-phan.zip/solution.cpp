#include <iostream>

using namespace std;

const long long MOD = 1000000007LL;

long long power2(long long exp) {
    long long res = 1;
    long long base = 2;
    while (exp > 0) {
        if (exp % 2 == 1) res = (res * base) % MOD;
        base = (base * base) % MOD;
        exp /= 2;
    }
    return res;
}

int main() {
    #ifndef ONLINE_JUDGE
    if (fopen("BITSTRINGS.INP", "r")) {
        freopen("BITSTRINGS.INP", "r", stdin);
        freopen("BITSTRINGS.OUT", "w", stdout);
    }
    #endif

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long n;
    if (cin >> n) {
        cout << power2(n) << "\n";
    }

    return 0;
}
