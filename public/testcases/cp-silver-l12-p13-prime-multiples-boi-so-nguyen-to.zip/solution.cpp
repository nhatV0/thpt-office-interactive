#include <iostream>
#include <numeric>

using namespace std;

long long lcm(long long a, long long b) {
    if (a == 0 || b == 0) return 0;
    return (a / std::gcd(a, b)) * b;
}

void solve() {
    long long a, b, c;
    cin >> a >> b >> c;

    long long m1 = b / std::gcd(a, b);
    long long m2 = c / std::gcd(b, c);
    long long m3 = a / std::gcd(c, a);

    long long ans = lcm(m1, lcm(m2, m3));
    cout << ans << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int t;
    if (cin >> t) {
        while (t--) {
            solve();
        }
    }

    return 0;
}
