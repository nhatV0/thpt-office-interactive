#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    double a, b, c;
    if (cin >> a >> b >> c) {
        double dtb = (2.0 * a + 2.0 * b + c) / 5.0;
        const double EPS = 1e-9;

        if (dtb + EPS >= 8.0) {
            cout << "gioi\n";
        } else if (dtb + EPS >= 6.5) {
            cout << "kha banh\n";
        } else if (dtb + EPS >= 5.0) {
            cout << "trung binh\n";
        } else {
            cout << "yeu\n";
        }
    }

    return 0;
}
