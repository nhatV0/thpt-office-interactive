#include <iostream>
#include <cmath>

using namespace std;

typedef unsigned __int128 u128;

u128 safe_pow(u128 base, int exp) {
    u128 res = 1;
    u128 max_limit = (u128)2e18 + 7;
    for (int i = 0; i < exp; ++i) {
        if (base != 0 && res > max_limit / base) return max_limit;
        res *= base;
    }
    return res;
}

long long solve(long long x) {
    if (x == 1) return 1;

    for (int b = 60; b >= 1; --b) {
        long long low = 1, high = 1e9 + 5;

        if (b == 2) high = 1000000000LL;
        else if (b == 3) high = 1000000LL;
        else if (b == 4) high = 31622LL;
        else if (b >= 60) high = 2;
        else {
            double approx = pow((double)x, 1.0 / b);
            high = (long long)(approx + 5);
        }

        long long ans_a = -1;
        while (low <= high) {
            long long mid = low + (high - low) / 2;
            u128 p = safe_pow(mid, b);

            if (p == (u128)x) {
                ans_a = mid;
                break;
            } else if (p < (u128)x) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        if (ans_a != -1) return ans_a;
    }

    return x;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int t;
    if (!(cin >> t)) return 0;

    while (t--) {
        long long x;
        cin >> x;
        cout << solve(x) << "\n";
    }

    return 0;
}
