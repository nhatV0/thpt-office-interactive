#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

bool isPrime(int n) {
    if (n < 2) return false;
    if (n == 2 || n == 3) return true;
    if (n % 2 == 0 || n % 3 == 0) return false;
    for (int i = 5; i * i <= n; i += 6) {
        if (n % i == 0 || n % (i + 2) == 0) return false;
    }
    return true;
}

int main() {
    #ifndef ONLINE_JUDGE
    if (fopen("PRIME.INP", "r")) {
        freopen("PRIME.INP", "r", stdin);
        freopen("PRIME.OUT", "w", stdout);
    }
    #endif

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    if (cin >> n) {
        vector<int> a(n + 1);
        int max_prime = -1;

        for (int i = 1; i <= n; ++i) {
            cin >> a[i];
            if (isPrime(a[i])) {
                if (a[i] > max_prime) {
                    max_prime = a[i];
                }
            }
        }

        if (max_prime != -1) {
            cout << max_prime << "\n";
            vector<int> indices;
            for (int i = 1; i <= n; ++i) {
                if (a[i] == max_prime) {
                    indices.push_back(i);
                }
            }
            for (size_t i = 0; i < indices.size(); ++i) {
                cout << indices[i] << (i + 1 == indices.size() ? "" : " ");
            }
            cout << "\n";
        }
    }

    return 0;
}
