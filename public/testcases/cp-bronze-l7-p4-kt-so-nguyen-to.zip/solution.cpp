#include <iostream>

using namespace std;

bool isPrime(long long n) {
    if (n <= 1) return false;
    if (n == 2 || n == 3) return true;
    if (n % 2 == 0 || n % 3 == 0) return false;
    
    for (long long i = 5; i * i <= n; i += 6) {
        if (n % i == 0 || n % (i + 2) == 0) return false;
    }
    return true;
}

int main() {
    #ifndef ONLINE_JUDGE
    if (fopen("CHECKPRIME.INP", "r")) {
        freopen("CHECKPRIME.INP", "r", stdin);
        freopen("CHECKPRIME.OUT", "w", stdout);
    }
    #endif

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long n;
    if (cin >> n) {
        if (isPrime(n)) {
            cout << "YES\n";
        } else {
            cout << "NO\n";
        }
    }

    return 0;
}
