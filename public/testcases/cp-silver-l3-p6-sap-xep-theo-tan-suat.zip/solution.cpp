#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const int INF = 1e9;

struct SegmentTree {
    int n;
    vector<int> tree;

    SegmentTree(int n) : n(n) {
        tree.assign(4 * n + 5, INF);
    }

    void build(const vector<int>& a, int node, int start, int end) {
        if (start == end) {
            tree[node] = a[start];
            return;
        }
        int mid = (start + end) / 2;
        build(a, node * 2, start, mid);
        build(a, node * 2 + 1, mid + 1, end);
        tree[node] = min(tree[node * 2], tree[node * 2 + 1]);
    }

    void update(int node, int start, int end, int idx, int val) {
        if (start == end) {
            tree[node] = val;
            return;
        }
        int mid = (start + end) / 2;
        if (start <= idx && idx <= mid)
            update(node * 2, start, mid, idx, val);
        else
            update(node * 2 + 1, mid + 1, end, idx, val);
        tree[node] = min(tree[node * 2], tree[node * 2 + 1]);
    }

    int query(int node, int start, int end, int l, int r) {
        if (r < start || end < l) return INF;
        if (l <= start && end <= r) return tree[node];
        int mid = (start + end) / 2;
        return min(query(node * 2, start, mid, l, r),
                   query(node * 2 + 1, mid + 1, end, l, r));
    }
};

void solve() {
    int n;
    if (!(cin >> n)) return;

    vector<int> a(n + 1), b(n + 1);
    vector<vector<int>> pos(n + 1);

    for (int i = 1; i <= n; ++i) {
        cin >> a[i];
        pos[a[i]].push_back(i);
    }

    for (int i = 1; i <= n; ++i) {
        cin >> b[i];
    }

    for (int v = 1; v <= n; ++v) {
        reverse(pos[v].begin(), pos[v].end());
    }

    SegmentTree st(n);
    st.build(a, 1, 1, n);

    bool ok = true;
    for (int j = 1; j <= n; ++j) {
        int val = b[j];
        if (pos[val].empty()) {
            ok = false;
            break;
        }
        int orig_idx = pos[val].back();
        pos[val].pop_back();

        int min_val = st.query(1, 1, n, 1, orig_idx);
        if (min_val < val) {
            ok = false;
            break;
        }

        st.update(1, 1, n, orig_idx, INF);
    }

    if (ok) cout << "YES\n";
    else cout << "NO\n";
}

int main() {
    freopen("SORT.INP", "r", stdin);
    freopen("SORT.OUT", "w", stdout);

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int t;
    if (cin >> t) {
        while (t--) {
            solve();
        }
    }
    return 0;
}
