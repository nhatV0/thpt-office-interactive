#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long n;
    if (cin >> n) {
        if (n <= 1) {
            cout << "NO\n";
            return 0;
        }

        long long sum = 0;
        for (long long i = 1; i * i <= n; ++i) {
            if (n % i == 0) {
                sum += i;
                if (i * i != n) {
                    sum += n / i;
                }
            }
        }

        if (sum == 2 * n) {
            cout << "YES\n";
        } else {
            cout << "NO\n";
        }
    }

    return 0;
}
