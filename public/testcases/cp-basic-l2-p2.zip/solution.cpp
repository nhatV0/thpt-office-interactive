#include <iostream>
#include <algorithm>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long a, b, c;
    if (cin >> a >> b >> c) {
        long long max_val = max({a, b, c});
        cout << max_val << "\n";
    }

    return 0;
}
