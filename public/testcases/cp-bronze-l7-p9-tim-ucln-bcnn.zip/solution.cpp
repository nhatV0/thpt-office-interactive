#include <iostream>
#include <numeric>
#include <algorithm>

using namespace std;

long long gcd(long long a, long long b) {
    while (b > 0) {
        long long r = a % b;
        a = b;
        b = r;
    }
    return a;
}

int main() {
    #ifndef ONLINE_JUDGE
    if (fopen("GCDLCM.INP", "r")) {
        freopen("GCDLCM.INP", "r", stdin);
        freopen("GCDLCM.OUT", "w", stdout);
    }
    #endif

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long a, b;
    if (cin >> a >> b) {
        long long g = gcd(a, b);
        long long l = (a / g) * b;

        cout << g << " " << l << "\n";
    }

    return 0;
}
