#include <iostream>
#include <vector>
#include <numeric>

using namespace std;

const int MAX_VAL = 1000000;
int spf[MAX_VAL + 1];
int omega[MAX_VAL + 1];

void precompute() {
    for (int i = 1; i <= MAX_VAL; ++i) {
        spf[i] = i;
    }
    for (int i = 2; i * i <= MAX_VAL; ++i) {
        if (spf[i] == i) {
            for (int j = i * i; j <= MAX_VAL; j += i) {
                if (spf[j] == j) {
                    spf[j] = i;
                }
            }
        }
    }

    omega[1] = 0;
    for (int i = 2; i <= MAX_VAL; ++i) {
        omega[i] = omega[i / spf[i]] + 1;
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    precompute();

    int t;
    if (!(cin >> t)) return 0;

    while (t--) {
        int a, b;
        cin >> a >> b;

        int g = std::gcd(a, b);
        int ans = omega[a] + omega[b] - 2 * omega[g];
        cout << ans << "\n";
    }

    return 0;
}
