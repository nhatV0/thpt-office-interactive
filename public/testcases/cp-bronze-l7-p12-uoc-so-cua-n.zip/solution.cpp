#include <iostream>

using namespace std;

long long countDivisors(long long n) {
    long long count = 0;
    for (long long i = 1; i * i <= n; ++i) {
        if (n % i == 0) {
            if (i * i == n) {
                count += 1;
            } else {
                count += 2;
            }
        }
    }
    return count;
}

int main() {
    #ifndef ONLINE_JUDGE
    if (fopen("NUM_DIVISORS.INP", "r")) {
        freopen("NUM_DIVISORS.INP", "r", stdin);
        freopen("NUM_DIVISORS.OUT", "w", stdout);
    }
    #endif

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long n;
    if (cin >> n) {
        cout << countDivisors(n) << "\n";
    }

    return 0;
}
