#include <iostream>
#include <algorithm>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long a, b, c, d;
    if (cin >> a >> b >> c >> d) {
        long long min_val = min({a, b, c, d});
        cout << min_val << "\n";
    }

    return 0;
}
