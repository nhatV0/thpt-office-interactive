#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

void print128(__int128 n) {
    if (n == 0) {
        cout << 0 << "\n";
        return;
    }
    string s = "";
    while (n > 0) {
        s += (char)('0' + (n % 10));
        n /= 10;
    }
    reverse(s.begin(), s.end());
    cout << s << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    unsigned long long raw_i, raw_j;
    if (cin >> raw_i >> raw_j) {
        __int128 i = raw_i;
        __int128 j = raw_j;

        __int128 count = j - i + 1;
        __int128 sum = (i + j) * count / 2;

        print128(sum);
    }
    return 0;
}
