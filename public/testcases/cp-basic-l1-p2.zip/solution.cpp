#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long x, y, z;
    if (cin >> x >> y >> z) {
        long long ans = (x - y) * z;
        cout << ans << "\n";
    }
    return 0;
}
