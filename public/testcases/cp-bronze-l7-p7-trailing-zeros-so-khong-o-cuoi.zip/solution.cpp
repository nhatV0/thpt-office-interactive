#include <iostream>

using namespace std;

long long countTrailingZeros(long long n) {
    long long count = 0;
    while (n >= 5) {
        count += n / 5;
        n /= 5;
    }
    return count;
}

int main() {
    #ifndef ONLINE_JUDGE
    if (fopen("TRAILINGZEROS.INP", "r")) {
        freopen("TRAILINGZEROS.INP", "r", stdin);
        freopen("TRAILINGZEROS.OUT", "w", stdout);
    }
    #endif

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    long long n;
    if (cin >> n) {
        cout << countTrailingZeros(n) << "\n";
    }

    return 0;
}
