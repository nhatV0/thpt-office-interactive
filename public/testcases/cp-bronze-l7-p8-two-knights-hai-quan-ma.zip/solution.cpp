#include <iostream>

using namespace std;

long long countTwoKnights(long long k) {
    if (k == 1) return 0;
    long long total_ways = (k * k) * (k * k - 1) / 2;
    long long attacking_ways = 4 * (k - 1) * (k - 2);
    return total_ways - attacking_ways;
}

int main() {
    #ifndef ONLINE_JUDGE
    if (fopen("TWOKNIGHTS.INP", "r")) {
        freopen("TWOKNIGHTS.INP", "r", stdin);
        freopen("TWOKNIGHTS.OUT", "w", stdout);
    }
    #endif

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    if (cin >> n) {
        for (int k = 1; k <= n; ++k) {
            cout << countTwoKnights(k) << "\n";
        }
    }

    return 0;
}
