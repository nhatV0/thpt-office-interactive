#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    double kg;
    if (cin >> kg) {
        double pound = kg * 2.205;
        cout << fixed << setprecision(2) << pound << "\n";
    }
    return 0;
}
